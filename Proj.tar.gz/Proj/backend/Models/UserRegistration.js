const mongoose = require('mongoose');

const { Schema, model } = mongoose;
const UserRegistrationSchema = new Schema({
    fullname : String,
    email : String,
    password : String,
    phone : String,
});


const UserRegistrationModel = model('UserRergistration', UserRegistrationSchema);

module.exports =  UserRegistrationModel;