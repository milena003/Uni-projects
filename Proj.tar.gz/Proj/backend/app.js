const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const { Schema, model } = mongoose;
const fs = require('fs');
const UserRegistrationModel = require('./Models/UserRegistration.js'); // holds the Mongoose schema for user registration

const app = express();
const mongoURI = 'mongodb://127.0.0.1:27017/project';
mongoose.connect(mongoURI,{ useNewUrlParser: true, useUnifiedTopology: true });

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cors()); // uses the cors middleware
const db = mongoose.connection;

// MongoDB connection events
db.on('error', console.error.bind(console, 'MongoDB connection error:'));
db.once('open', () => {
    console.log('Connected to database ' + mongoURI);
});


function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function isStrongPassword(password) {
    const passwordRegex = /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*()_+}{"':;?/>.<,])(?=.*[^\s]).{8,}$/;
    return passwordRegex.test(password);
}

function isValidPhoneNumber(phone) {
    const phoneRegex = /^[0-9-+\s()]+$/;
    return phoneRegex.test(phone);
}


app.post('/register',  async(req, res) => {
    const isUserExist = await UserRegistrationModel.findOne({ email : req.body.email });; // check if user already exists
    if (isUserExist) { // if user already exists send a message to frontend
        res.status(400).json({ error : 'User already registered' });
    }
    const { fullname, email, password, phone } = req.body; // get all data from request
    
    if (fullname === '' || email === '' || password === '' || phone === '') {
        return res.status(403).json({ error : ''});
    }

    // validation checking
    if (!isValidEmail(email)) {
        return res.status(403).json({ error: 'Invalid email format' });
    }

    if (!isStrongPassword(password)) {
        return res.status(403).json({ error: 'Password is not strong enough' });
    }

    if (!isValidPhoneNumber(phone)) {
        return res.status(403).json({ error: 'Invalid phone number format' });
    }
    /////////////////////

    try {
        const newUser = new UserRegistrationModel({
            fullname,
            email,
            password,
            phone,
        }); // create user with incoming datas
        
        await newUser.save(); // save data
        res.json({ status : true, data : newUser});
    } catch (e) {
        res.json({ status : false })
        return;
    };
});


// login checking 
app.post('/login', async(req, res) => {
    console.log(req.body);
    const { email, password } = req.body;
    const isUserExist = await UserRegistrationModel.findOne({ email }); //check in database isUserExist with that incoming email
    if (!isUserExist) { // confirm password if user exists
        res.json({ status : false }) 
        return;
    }
    if (isUserExist &&  isUserExist.password !== password) {
        res.json({ status : false });
        return;
    }

    res.json({ status : true });
});


// saving in file 
app.post("/register2", (req, res) => {
    const email = req.body.email;
    fs.readFile('./db.json', (err, data) => {
        const db = JSON.parse(data.toString());
        const findWithEmail = db.find((item) => item.email === email);
        if (!findWithEmail) {
            db.push(req.body);
            fs.writeFile('./db.json', JSON.stringify(db), (err) => {
                res.json({ message: "Registred successfully" });
            });
        } else {
            res.json({ message: "User with this email already exist" })
        };
    });
});

app.post('/login2', (req, res) => {
    const email = req.body.email;
    const password = req.body.password;

    fs.readFile('./db.json', (err, data) => {
        const db = JSON.parse(data.toString());
        const findWithEmail = db.find((item) => item.email === email && item.password === password);
        if (findWithEmail) {
            res.json(findWithEmail);
        } else {
            res.json({
                message: "User not found"
            });
        };
    });
});
////////////////////////////


// server listens on 7054 port
app.listen(7054, () => {
    console.log('Listening on port 7054');
});