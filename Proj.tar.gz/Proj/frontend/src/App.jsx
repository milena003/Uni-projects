import './App.css';
import Login from './Components/Login/Login';
import Register from './Components/Register/Register';
import Welcome from './Components/Welcome/Welcome';
import { useState } from 'react';

function App() {
  const [loginPage, setLoginPage] = useState(true);
  const [registerPage, setRegisterPage] = useState(false);
  const [welcomePage, setWelcomePage] = useState(false);
  
  return (
    loginPage ? (
      <Login setLoginPage={setLoginPage} setWelcomePage={setWelcomePage} setRegisterPage={setRegisterPage} />
    ) : registerPage ? (
      <Register setLoginPage={setLoginPage} setWelcomePage={setWelcomePage} setRegisterPage={setRegisterPage}/>
    ) : welcomePage ? (
      <Welcome setLoginPage={setLoginPage} setWelcomePage={setWelcomePage}/>
    ) : null
  );
};

export default App;