import { useState } from 'react'
import './style.css'


const Register = ({setLoginPage, setWelcomePage, setRegisterPage }) => { // React component
    const [fullname, setFullname] = useState('');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');

    const handleRegister = async() => { // asynch() => this function may contain asynchronous operations that will be handled with await.
        const dataToSend = {
            fullname,
            email,
            phone,
            password
        }
        
        try {
            const res =  await fetch('http://127.0.0.1:7054/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(dataToSend) // in the body json data
            }).then(async (res) => {
                return await res.json()
            });

            if (!res.status) {
                alert(res.error);
                return;
            };

            setLoginPage(true);
            setRegisterPage(false);
            setWelcomePage(false);
        } catch(e) {
            alert('Oops! Something went wrong');
        }
    };


    return (
        <section>
            <div class="wrapper">
                <div class="center-wrap">
                    <div class="section text-center">
                        <h2 >Sign Up</h2>

                        <div class="form-group">
                            <ion-icon name="person-circle-outline"></ion-icon>
                            <input type="text" value={fullname} placeholder="Full Name" required onChange={(e) => setFullname(e.target.value)} />
                        </div>	

                        <div class="form-group">
                            <ion-icon name="call-outline"></ion-icon>
                            <input type="tel" value={phone} placeholder="Phone Number" required onChange={(e)=> setPhone(e.target.value)} />
                        </div>	

                        <div class="form-group">
                            <ion-icon name="at-outline"></ion-icon>                    
                            <input type="email" value={email} placeholder="Email" required onChange={(e) => setEmail(e.target.value)}  />
                        </div>

                        <div class="form-group">
                            <ion-icon name="lock-closed-outline"></ion-icon>                    
                            <input type="password" value={password} placeholder="Password" onChange={(e) => setPassword(e.target.value)} />
                        </div>
                        <div className='enter'>
                            <button style={{ width : '100%'}} onClick={handleRegister}>Register</button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    );
};

export default Register;