import { useState } from 'react';
import './style.css';


const Login = ({setLoginPage, setWelcomePage, setRegisterPage }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');

    const handleEmailChange = (e) => {
        setEmail(e.target.value);
    };

    const handlePasswordChange = (e) => {
        setPassword(e.target.value);
    };

    const handleLogin = async (e) => {
        e.preventDefault(); //handles the login process
        console.log(email, password);
        const dataToSend = {
            email,
            password
        };
        try {
            const res =  await fetch('http://127.0.0.1:7054/login', {
                // sends the login credentials (dataToSend) as JSON in the request body.
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body : JSON.stringify(dataToSend)
                }).then(async (res) => {
                return await res.json(); // code awaits conversion of the response to JSON format 
            });
    
            console.log(res);
            if (!res.status) {
                alert(res.error);
                return;
            }
    
            setLoginPage(false);
            setWelcomePage(true);

        } catch(e) {
            alert(`Oops! Something went wrong`);
        }
    }

    const handleRegisterPageClick = () => {
        setRegisterPage(true);
        setLoginPage(false);
    }
    
    
    return (
        <section>
            <div class="form-box">
                <div class="form-value">
                    <form action="">
                        <h2>Log In</h2>
                        <div class="input-box">
                        <ion-icon name = "lock-closed-outline"></ion-icon>
                            <input type="email" onChange={handleEmailChange} value={email} required />
                            <label for="">Email</label>
                        </div>

                        <div class="input-box">
                            <ion-icon name = "lock-closed-outline"></ion-icon>
                            <input type="password" value={password} onChange={handlePasswordChange} required />
                            <label for="">Password</label>
                        </div>

                        <div class="forget" style={{ justifyContent : 'flex-start'}}>
                            <label for="">
                            </label>
                                <input type="checkbox" style={{ width : 'unset'}} /> Remember me <a href="#" style={{ paddingLeft : '77px', color :'#fff'}}>Forgot password?</a>
                        </div>

                        <button style={{ width : '95%'}} onClick={handleLogin}>Log in</button>
                        <div class="register">
                            <p>Don't have an accaount? <a href="#" onClick={handleRegisterPageClick}>Sign up</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </section>
    );
};

export default Login;