import './style.css'


const Welcome = ({ setWelcomePage, setLoginPage }) => {
    const handleLogOut = () => {
        setWelcomePage(false);
        setLoginPage(true);
    }

    return (
        <section>
        <div class="hey">
            <h1 class="welcome">You've sucessfully signed up</h1>
        </div>
            <button  class="leave" onClick={handleLogOut}>Log out</button>
        </section>
    );
};

export default Welcome;